import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() {
  runApp(const YoutubeImporterApp());
}

// =======================================================
// THEME / PALETTE
// =======================================================
class AppColors {
  static const Color primary = Color(0xFF6C4AB6); // deep violet
  static const Color primaryDark = Color(0xFF43276B);
  static const Color accent = Color(0xFF12B8A1); // teal accent
  static const Color bg = Color(0xFFF6F5FB);
  static const Color cardBg = Colors.white;
  static const Color chipBg = Color(0xFFEDE7F9);
  static const Color textDark = Color(0xFF241C3B);
  static const Color textMuted = Color(0xFF7A7290);
  static const Color danger = Color(0xFFE85D5D);
  static const Color gold = Color(0xFFF5A623);
  static const Color youtubeRed = Color(0xFFFF3B3B);

  static const List<Color> headerGradient = [
    Color(0xFF6C4AB6),
    Color(0xFF8E6FE0),
  ];
}

class YoutubeImporterApp extends StatelessWidget {
  const YoutubeImporterApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'YouTube Video Importer',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: AppColors.bg,
        colorScheme: ColorScheme.fromSeed(
          seedColor: AppColors.primary,
          primary: AppColors.primary,
          secondary: AppColors.accent,
        ),
        fontFamily: 'Roboto',
        textTheme: const TextTheme(
          titleLarge: TextStyle(
            fontWeight: FontWeight.w800,
            color: AppColors.textDark,
          ),
          titleMedium: TextStyle(
            fontWeight: FontWeight.w700,
            color: AppColors.textDark,
          ),
          bodyMedium: TextStyle(color: AppColors.textDark),
        ),
      ),
      home: const YoutubePage(),
    );
  }
}

class ApiConfig {
  static const String serverSaveUrl = 'https://galang.sbs/save_videos.php';

  static const String serverListUrl = 'https://galang.sbs/list_videos.php';

  static const String youtubeApiKey = 'AIzaSyBiIgY5vodcPMROd2mfdpQ08Vb-jK17viI';
}

class VideoModel {
  final String videoId;
  final String title;
  final String description;
  final String channelTitle;
  final String? publishedAt;
  final String? thumbnail;
  final String? viewCount;
  final String? likeCount;
  final String? duration;
  final Map<String, dynamic> rawJson;

  VideoModel({
    required this.videoId,
    required this.title,
    required this.description,
    required this.channelTitle,
    this.publishedAt,
    this.thumbnail,
    this.viewCount,
    this.likeCount,
    this.duration,
    required this.rawJson,
  });

  factory VideoModel.fromSearchJson(Map<String, dynamic> item) {
    final Map<String, dynamic> snippet = item['snippet'] is Map<String, dynamic>
        ? item['snippet'] as Map<String, dynamic>
        : <String, dynamic>{};

    final dynamic idField = item['id'];
    String videoId = '';
    if (idField is Map<String, dynamic>) {
      videoId = idField['videoId']?.toString() ?? '';
    } else if (idField is String) {
      videoId = idField;
    }

    String? thumbnail;
    if (snippet['thumbnails'] is Map<String, dynamic>) {
      final thumbs = snippet['thumbnails'] as Map<String, dynamic>;
      final medium = thumbs['medium'] ?? thumbs['default'];
      if (medium is Map<String, dynamic>) {
        thumbnail = medium['url']?.toString();
      }
    }

    return VideoModel(
      videoId: videoId,
      title: snippet['title']?.toString() ?? 'Tanpa Judul',
      description: snippet['description']?.toString() ?? '',
      channelTitle: snippet['channelTitle']?.toString() ?? '-',
      publishedAt: snippet['publishedAt']?.toString(),
      thumbnail: thumbnail,
      rawJson: item,
    );
  }

  factory VideoModel.fromServerJson(Map<String, dynamic> item) {
    return VideoModel(
      videoId: item['video_id']?.toString() ?? '',
      title: item['title']?.toString() ?? 'Tanpa Judul',
      description: item['description']?.toString() ?? '',
      channelTitle: item['channel_title']?.toString() ?? '-',
      publishedAt: item['published_at']?.toString(),
      thumbnail: item['thumbnail']?.toString(),
      viewCount: item['view_count']?.toString(),
      likeCount: item['like_count']?.toString(),
      duration: item['duration']?.toString(),
      rawJson: item,
    );
  }

  VideoModel copyWithStats({
    String? viewCount,
    String? likeCount,
    String? duration,
  }) {
    return VideoModel(
      videoId: videoId,
      title: title,
      description: description,
      channelTitle: channelTitle,
      publishedAt: publishedAt,
      thumbnail: thumbnail,
      viewCount: viewCount ?? this.viewCount,
      likeCount: likeCount ?? this.likeCount,
      duration: duration ?? this.duration,
      rawJson: rawJson,
    );
  }

  Map<String, dynamic> toServerJson() {
    return {
      'video_id': videoId,
      'title': title,
      'description': description,
      'channel_title': channelTitle,
      'published_at': publishedAt,
      'thumbnail': thumbnail,
      'view_count': viewCount,
      'like_count': likeCount,
      'duration': duration,
      'raw_json': rawJson,
    };
  }
}

class YoutubePage extends StatefulWidget {
  const YoutubePage({super.key});

  @override
  State<YoutubePage> createState() => _YoutubePageState();
}

class _YoutubePageState extends State<YoutubePage> {
  final TextEditingController searchController = TextEditingController();

  List<VideoModel> videos = [];
  List<VideoModel> savedVideos = [];

  Set<String> selectedVideoIds = {};

  bool isLoadingSearch = false;
  bool isSavingVideos = false;
  bool isLoadingSavedVideos = false;

  int maxResults = 10;
  String selectedOrder = 'relevance';

  @override
  void initState() {
    super.initState();
    loadSavedVideos();
  }

  Future<Map<String, dynamic>> decodeJsonResponse(
      http.Response response) async {
    try {
      return jsonDecode(response.body) as Map<String, dynamic>;
    } catch (_) {
      throw Exception(
        'Response server bukan JSON valid. '
        'Status: ${response.statusCode}. '
        'Isi response: ${response.body.substring(0, response.body.length > 200 ? 200 : response.body.length)}',
      );
    }
  }

  Future<void> searchVideosFromYoutube() async {
    final String query = searchController.text.trim();

    if (query.isEmpty) {
      showMessage('Masukkan kata kunci pencarian video.', isError: true);
      return;
    }

    setState(() {
      isLoadingSearch = true;
      videos = [];
      selectedVideoIds = {};
    });

    try {
      final Map<String, String> queryParams = {
        'part': 'snippet',
        'type': 'video',
        'q': query,
        'maxResults': maxResults.toString(),
        'order': selectedOrder,
        'key': ApiConfig.youtubeApiKey,
      };

      final Uri searchUri = Uri.https(
        'www.googleapis.com',
        '/youtube/v3/search',
        queryParams,
      );

      final http.Response searchResponse = await http.get(searchUri);

      if (searchResponse.statusCode != 200) {
        throw Exception(
          'Gagal mengambil data dari YouTube Data API. '
          'Status code: ${searchResponse.statusCode}',
        );
      }

      final Map<String, dynamic> decoded =
          jsonDecode(searchResponse.body) as Map<String, dynamic>;

      final dynamic items = decoded['items'];

      if (items == null || items is! List || items.isEmpty) {
        showMessage('Video tidak ditemukan.', isError: true);
        return;
      }

      List<VideoModel> result = items
          .whereType<Map<String, dynamic>>()
          .map(VideoModel.fromSearchJson)
          .where((video) => video.videoId.isNotEmpty)
          .toList();

      // Ambil statistik (view count, like count, duration) lewat endpoint videos.
      result = await enrichWithStatistics(result);

      setState(() {
        videos = result;
        selectedVideoIds = result.map((video) => video.videoId).toSet();
      });

      showMessage('${result.length} video berhasil diambil dari YouTube.');
    } catch (e) {
      showMessage('Error mengambil data: $e', isError: true);
    } finally {
      setState(() {
        isLoadingSearch = false;
      });
    }
  }

  Future<List<VideoModel>> enrichWithStatistics(
      List<VideoModel> baseVideos) async {
    if (baseVideos.isEmpty) return baseVideos;

    try {
      final String ids = baseVideos.map((v) => v.videoId).join(',');

      final Uri statsUri = Uri.https(
        'www.googleapis.com',
        '/youtube/v3/videos',
        {
          'part': 'statistics,contentDetails',
          'id': ids,
          'key': ApiConfig.youtubeApiKey,
        },
      );

      final http.Response statsResponse = await http.get(statsUri);

      if (statsResponse.statusCode != 200) return baseVideos;

      final Map<String, dynamic> decoded =
          jsonDecode(statsResponse.body) as Map<String, dynamic>;

      final dynamic items = decoded['items'];
      if (items == null || items is! List) return baseVideos;

      final Map<String, Map<String, dynamic>> statsMap = {};
      for (final item in items.whereType<Map<String, dynamic>>()) {
        final id = item['id']?.toString();
        if (id == null) continue;
        statsMap[id] = item;
      }

      return baseVideos.map((video) {
        final data = statsMap[video.videoId];
        if (data == null) return video;

        final statistics = data['statistics'] is Map<String, dynamic>
            ? data['statistics'] as Map<String, dynamic>
            : <String, dynamic>{};
        final contentDetails = data['contentDetails'] is Map<String, dynamic>
            ? data['contentDetails'] as Map<String, dynamic>
            : <String, dynamic>{};

        return video.copyWithStats(
          viewCount: statistics['viewCount']?.toString(),
          likeCount: statistics['likeCount']?.toString(),
          duration: contentDetails['duration']?.toString(),
        );
      }).toList();
    } catch (_) {
      return baseVideos;
    }
  }

  Future<void> saveSelectedVideosToServer() async {
    final List<VideoModel> selectedVideos = videos
        .where((video) => selectedVideoIds.contains(video.videoId))
        .toList();

    if (selectedVideos.isEmpty) {
      showMessage('Pilih minimal satu video untuk disimpan.', isError: true);
      return;
    }

    setState(() {
      isSavingVideos = true;
    });

    try {
      final Uri uri = Uri.parse(ApiConfig.serverSaveUrl);

      final http.Response response = await http.post(
        uri,
        headers: {
          'Content-Type': 'application/json; charset=utf-8',
          'Accept': 'application/json',
        },
        body: jsonEncode({
          'videos':
              selectedVideos.map((video) => video.toServerJson()).toList(),
        }),
      );

      final Map<String, dynamic> decoded = await decodeJsonResponse(response);

      if (response.statusCode != 200 || decoded['success'] != true) {
        throw Exception(decoded['message'] ?? 'Gagal menyimpan data.');
      }

      final dynamic savedCount = decoded['data']?['saved_count'];

      showMessage(
        'Berhasil menyimpan ${savedCount ?? selectedVideos.length} video ke database.',
      );

      await loadSavedVideos();
    } catch (e) {
      showMessage('Error menyimpan data: $e', isError: true);
    } finally {
      setState(() {
        isSavingVideos = false;
      });
    }
  }

  Future<void> loadSavedVideos() async {
    setState(() {
      isLoadingSavedVideos = true;
    });

    try {
      final Uri uri = Uri.parse(ApiConfig.serverListUrl);

      final http.Response response = await http.get(
        uri,
        headers: {
          'Accept': 'application/json',
        },
      );

      final Map<String, dynamic> decoded = await decodeJsonResponse(response);

      if (response.statusCode != 200 || decoded['success'] != true) {
        throw Exception(
            decoded['message'] ?? 'Gagal mengambil data tersimpan.');
      }

      final dynamic data = decoded['data'];

      if (data is List) {
        setState(() {
          savedVideos = data
              .whereType<Map<String, dynamic>>()
              .map(VideoModel.fromServerJson)
              .toList();
        });
      }
    } catch (e) {
      showMessage('Error mengambil data tersimpan: $e', isError: true);
    } finally {
      setState(() {
        isLoadingSavedVideos = false;
      });
    }
  }

  void toggleVideoSelection(VideoModel video) {
    setState(() {
      if (selectedVideoIds.contains(video.videoId)) {
        selectedVideoIds.remove(video.videoId);
      } else {
        selectedVideoIds.add(video.videoId);
      }
    });
  }

  void selectAllVideos() {
    setState(() {
      selectedVideoIds = videos.map((video) => video.videoId).toSet();
    });
  }

  void unselectAllVideos() {
    setState(() {
      selectedVideoIds.clear();
    });
  }

  void showMessage(String message, {bool isError = false}) {
    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        duration: const Duration(seconds: 4),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        backgroundColor: isError ? AppColors.danger : AppColors.primaryDark,
      ),
    );
  }

  String formatCount(String? raw) {
    if (raw == null) return '-';
    final int? value = int.tryParse(raw);
    if (value == null) return raw;
    if (value >= 1000000) {
      return '${(value / 1000000).toStringAsFixed(1)}jt';
    }
    if (value >= 1000) {
      return '${(value / 1000).toStringAsFixed(1)}rb';
    }
    return value.toString();
  }

  String formatDuration(String? iso) {
    if (iso == null || iso.isEmpty) return '-';
    final match =
        RegExp(r'PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?').firstMatch(iso);
    if (match == null) return '-';
    final hours = match.group(1);
    final minutes = match.group(2) ?? '0';
    final seconds = (match.group(3) ?? '0').padLeft(2, '0');
    if (hours != null) {
      return '$hours:${minutes.padLeft(2, '0')}:$seconds';
    }
    return '$minutes:$seconds';
  }

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  // =======================================================
  // UI PIECES
  // =======================================================

  Widget buildHeader() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(20, 54, 20, 26),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: AppColors.headerGradient,
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(28),
          bottomRight: Radius.circular(28),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.18),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: const Icon(Icons.smart_display_rounded,
                    color: Colors.white, size: 26),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Text(
                  'YouTube Importer',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              IconButton(
                onPressed: loadSavedVideos,
                icon: const Icon(Icons.refresh, color: Colors.white),
                tooltip: 'Refresh data tersimpan',
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            'Cari video dari YouTube lalu simpan ke database kamu.',
            style: TextStyle(
              color: Colors.white.withOpacity(0.85),
              fontSize: 13,
            ),
          ),
          const SizedBox(height: 18),
          buildSearchBar(),
        ],
      ),
    );
  }

  Widget buildSearchBar() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.12),
            blurRadius: 14,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: TextField(
        controller: searchController,
        onSubmitted: (_) => searchVideosFromYoutube(),
        decoration: InputDecoration(
          hintText: 'Cari judul video, channel, topik...',
          hintStyle: const TextStyle(color: AppColors.textMuted),
          border: InputBorder.none,
          contentPadding:
              const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
          prefixIcon: const Icon(Icons.search, color: AppColors.primary),
          suffixIcon: Padding(
            padding: const EdgeInsets.all(6),
            child: Material(
              color: AppColors.primary,
              borderRadius: BorderRadius.circular(12),
              child: InkWell(
                borderRadius: BorderRadius.circular(12),
                onTap: isLoadingSearch ? null : searchVideosFromYoutube,
                child: SizedBox(
                  width: 44,
                  height: 44,
                  child: Center(
                    child: isLoadingSearch
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.white,
                            ),
                          )
                        : const Icon(Icons.arrow_forward,
                            color: Colors.white, size: 20),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget buildFilterRow() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 4),
      child: Row(
        children: [
          Expanded(child: buildResultCountChip()),
          const SizedBox(width: 10),
          Expanded(child: buildOrderChip()),
        ],
      ),
    );
  }

  Widget buildResultCountChip() {
    return _DropdownPill<int>(
      icon: Icons.format_list_numbered,
      value: maxResults,
      items: const {
        10: '10 Video',
        20: '20 Video',
        30: '30 Video',
        40: '40 Video',
      },
      onChanged: (value) {
        if (value != null) setState(() => maxResults = value);
      },
    );
  }

  Widget buildOrderChip() {
    return _DropdownPill<String>(
      icon: Icons.sort,
      value: selectedOrder,
      items: const {
        'relevance': 'Relevansi',
        'date': 'Terbaru',
        'viewCount': 'Views',
        'rating': 'Rating',
      },
      onChanged: (value) {
        setState(() => selectedOrder = value ?? 'relevance');
      },
    );
  }

  Widget buildActionBar() {
    if (videos.isEmpty) return const SizedBox.shrink();

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: AppColors.cardBg,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: AppColors.chipBg,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    '${selectedVideoIds.length}/${videos.length} dipilih',
                    style: const TextStyle(
                      color: AppColors.primary,
                      fontWeight: FontWeight.w700,
                      fontSize: 12,
                    ),
                  ),
                ),
                const Spacer(),
                TextButton(
                  onPressed: selectAllVideos,
                  child: const Text('Pilih Semua'),
                ),
                TextButton(
                  onPressed: unselectAllVideos,
                  child: const Text('Batal'),
                ),
              ],
            ),
            const SizedBox(height: 4),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                style: FilledButton.styleFrom(
                  backgroundColor: AppColors.accent,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 13),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                onPressed: isSavingVideos ? null : saveSelectedVideosToServer,
                icon: isSavingVideos
                    ? const SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: Colors.white,
                        ),
                      )
                    : const Icon(Icons.cloud_upload_outlined),
                label: Text(
                  isSavingVideos ? 'Menyimpan...' : 'Simpan ke Database',
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildThumbnail(String? thumbnail) {
    final placeholder = Container(
      width: 96,
      height: 66,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFFD9CFF2), Color(0xFFB9A6E8)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(10),
      ),
      child: const Icon(Icons.smart_display_rounded, color: Colors.white),
    );

    if (thumbnail == null || thumbnail.isEmpty) return placeholder;

    return ClipRRect(
      borderRadius: BorderRadius.circular(10),
      child: Image.network(
        thumbnail,
        width: 96,
        height: 66,
        fit: BoxFit.cover,
        errorBuilder: (context, error, stackTrace) => placeholder,
      ),
    );
  }

  Widget buildVideoCard(VideoModel video) {
    final bool isSelected = selectedVideoIds.contains(video.videoId);

    return GestureDetector(
      onTap: () => toggleVideoSelection(video),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: AppColors.cardBg,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
            color: isSelected ? AppColors.primary : Colors.transparent,
            width: 1.6,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.06),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            buildThumbnail(video.thumbnail),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    video.title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontWeight: FontWeight.w700,
                      fontSize: 14.5,
                      color: AppColors.textDark,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    video.channelTitle,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: AppColors.textMuted,
                      fontSize: 12.5,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: [
                      if (video.viewCount != null)
                        _MiniTag(
                          icon: Icons.visibility_outlined,
                          label: '${formatCount(video.viewCount)} x ditonton',
                        ),
                      if (video.duration != null)
                        _MiniTag(
                          icon: Icons.timer_outlined,
                          label: formatDuration(video.duration),
                        ),
                      if (video.likeCount != null)
                        _MiniTag(
                          icon: Icons.thumb_up_alt_outlined,
                          label: formatCount(video.likeCount),
                          color: AppColors.gold,
                        ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(width: 4),
            AnimatedContainer(
              duration: const Duration(milliseconds: 180),
              width: 24,
              height: 24,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: isSelected ? AppColors.primary : Colors.white,
                border: Border.all(
                  color: isSelected ? AppColors.primary : AppColors.textMuted,
                  width: 1.6,
                ),
              ),
              child: isSelected
                  ? const Icon(Icons.check, size: 15, color: Colors.white)
                  : null,
            ),
          ],
        ),
      ),
    );
  }

  Widget buildSearchResult() {
    if (isLoadingSearch) {
      return const Padding(
        padding: EdgeInsets.all(48),
        child: Center(
          child: CircularProgressIndicator(color: AppColors.primary),
        ),
      );
    }

    if (videos.isEmpty) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 40),
        child: Column(
          children: [
            Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                color: AppColors.chipBg,
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.search_off_rounded,
                  color: AppColors.primary, size: 34),
            ),
            const SizedBox(height: 14),
            const Text(
              'Belum ada hasil pencarian',
              style: TextStyle(
                fontWeight: FontWeight.w700,
                color: AppColors.textDark,
              ),
            ),
            const SizedBox(height: 4),
            const Text(
              'Ketik kata kunci di atas untuk mulai mencari video',
              style: TextStyle(color: AppColors.textMuted, fontSize: 12.5),
            ),
          ],
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.only(bottom: 10, left: 2),
            child: Text(
              'Hasil Pencarian',
              style: TextStyle(
                fontWeight: FontWeight.w800,
                fontSize: 15,
                color: AppColors.textDark,
              ),
            ),
          ),
          ...videos.map(buildVideoCard),
        ],
      ),
    );
  }

  Widget buildSavedVideosSection() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
      child: Container(
        decoration: BoxDecoration(
          color: AppColors.cardBg,
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Theme(
          data: Theme.of(context).copyWith(
            dividerColor: Colors.transparent,
          ),
          child: ExpansionTile(
            shape: const RoundedRectangleBorder(side: BorderSide.none),
            leading: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: AppColors.chipBg,
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(Icons.storage_rounded,
                  color: AppColors.primary, size: 20),
            ),
            title: const Text(
              'Video Tersimpan',
              style: TextStyle(fontWeight: FontWeight.w700),
            ),
            subtitle: Text('${savedVideos.length} video di database'),
            trailing: isLoadingSavedVideos
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: AppColors.primary,
                    ),
                  )
                : IconButton(
                    icon: const Icon(Icons.refresh, color: AppColors.primary),
                    onPressed: loadSavedVideos,
                  ),
            children: [
              if (savedVideos.isEmpty)
                const Padding(
                  padding: EdgeInsets.fromLTRB(16, 0, 16, 16),
                  child: Text(
                    'Belum ada data video tersimpan.',
                    style: TextStyle(color: AppColors.textMuted),
                  ),
                )
              else
                ...savedVideos.map(
                  (video) => Padding(
                    padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        buildThumbnail(video.thumbnail),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                video.title,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                    fontWeight: FontWeight.w700,
                                    fontSize: 13.5),
                              ),
                              const SizedBox(height: 3),
                              Text(
                                'Channel: ${video.channelTitle}',
                                style: const TextStyle(
                                    color: AppColors.textMuted, fontSize: 12),
                              ),
                              Text(
                                'Views: ${formatCount(video.viewCount)}',
                                style: const TextStyle(
                                    color: AppColors.textMuted, fontSize: 12),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              const SizedBox(height: 6),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        top: false,
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            buildHeader(),
            buildFilterRow(),
            buildActionBar(),
            buildSearchResult(),
            const SizedBox(height: 8),
            buildSavedVideosSection(),
          ],
        ),
      ),
    );
  }
}

// =======================================================
// SMALL REUSABLE WIDGETS
// =======================================================

class _MiniTag extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color? color;

  const _MiniTag({required this.icon, required this.label, this.color});

  @override
  Widget build(BuildContext context) {
    final c = color ?? AppColors.primary;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: c.withOpacity(0.10),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 12, color: c),
          const SizedBox(width: 4),
          Text(
            label,
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w600,
              color: c,
            ),
          ),
        ],
      ),
    );
  }
}

class _DropdownPill<T> extends StatelessWidget {
  final IconData icon;
  final T value;
  final Map<T, String> items;
  final ValueChanged<T?> onChanged;

  const _DropdownPill({
    required this.icon,
    required this.value,
    required this.items,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(
        color: AppColors.cardBg,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<T>(
          value: value,
          isExpanded: true,
          icon: const Icon(Icons.keyboard_arrow_down_rounded,
              color: AppColors.primary),
          items: items.entries
              .map(
                (e) => DropdownMenuItem<T>(
                  value: e.key,
                  child: Row(
                    children: [
                      Icon(icon, size: 15, color: AppColors.primary),
                      const SizedBox(width: 6),
                      Text(
                        e.value,
                        style: const TextStyle(
                          fontSize: 12.5,
                          fontWeight: FontWeight.w600,
                          color: AppColors.textDark,
                        ),
                      ),
                    ],
                  ),
                ),
              )
              .toList(),
          onChanged: onChanged,
        ),
      ),
    );
  }
}
